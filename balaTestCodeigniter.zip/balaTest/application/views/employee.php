<html>
<head>
  <title>Working with Datatables ajax in Codeigniter 3 with example</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"/>
</head>
<body>

<div class="container">
<div class="container">
  <div class="row ">
    <table id='employeeList' class="table table-bordered">
      <thead>
      <tr>
        <th>EmpId</th>
        <th>Name</th>
        <th>Age</th>
        <th>Skills</th>
        <th>Designation</th>
        <th>Address</th>
      </tr>
      </thead>
      <tbody></tbody>
    </table>
    <div id='pagination'></div> 
  </div>
</div>
</div>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script> 
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
<script type='text/javascript'>
$(document).ready(function() {
  createPagination(0);
  $('#pagination').on('click','a',function(e){
    e.preventDefault(); 
    var pageNum = $(this).attr('data-ci-pagination-page');
    createPagination(pageNum);
  });
  function createPagination(pageNum){
    $.ajax({
      url: '<?=base_url()?>index.php/Employee/loadData/'+pageNum,
      type: 'get',
      dataType: 'json',
      success: function(responseData){
        $('#pagination').html(responseData.pagination);
        paginationData(responseData.empData);
      }
    });
  }
  function paginationData(data) {
    $('#employeeList tbody').empty();
    for(emp in data){
      var empRow = "<tr>";
      empRow += "<td>"+ data[emp].id +"</td>";
      empRow += "<td>"+ data[emp].name +"</td>";
      empRow += "<td>"+ data[emp].age +"</td>"
      empRow += "<td>"+ data[emp].skills +"</td>"
      empRow += "<td>"+ data[emp].designation +"</td>"
      empRow += "<td><img src='../image/"+data[emp].skills+".png'  width='50' height='60' ></td>";
      empRow += "</tr>";
      $('#employeeList tbody').append(empRow);          
    }
  }
});
</script>

</body>

</html>